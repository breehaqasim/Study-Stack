#include <stdio.h>
#include <stdlib.h>
#include "my_c.h"

//push function of stack
void push(struct node **headaddr, int val)
{
    if (headaddr == NULL)
    {
        fprintf(stderr, "NULL ptr passed\n");
        exit(1);
    }

    struct node *n = malloc(sizeof(struct node));

    if (n == NULL)
    {
        fprintf(stderr, "memory allocation failed\n");
        exit(1);
    }

    n->val = val;
    n->next = *headaddr; //the new node points to current head
    *headaddr = n; //updating the head to new node

}

//pop function of stack
int pop(struct node **headaddr)
{
    if (headaddr == NULL)
    {
        fprintf(stderr, "NULL ptr passed\n");
        exit(1);
    }

    if (*headaddr == NULL)
    {
        // stack empty
        return -1;
    }
    else
    {
        struct node *n = *headaddr;
        *headaddr = (*headaddr)->next; //moving head to the next element
        int val = n->val;
        free(n); //free pop node
        return val;
    }
}

void print(struct node *head)
{
    if (head == NULL)
    {
        fprintf(stdout, "empty stack\n");
    }
    else
    {
        while (head != NULL)
        {
            fprintf(stdout, "%d ", head->val);
            head = head->next;
        }
        fprintf(stdout, "\n");
    }
}

int main()
{
    struct node *stack = NULL;

    push(&stack, 2);
    push(&stack, 4);
    push(&stack, 6);

    printf("Stack after pushing: ");
    print(stack);

    int poppedValue = pop(&stack);
    printf("Popped value: %d\n", poppedValue);

    printf("Stack after popping: ");
    print(stack);

    while (pop(&stack) != -1);

    return 0;
}
