#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

int main(void)
{
    //P2 writes it's message to P1 first
    int fd1, retval1;
    char buffer1[10];
    
    printf("P2: ");
    fgets(buffer1, sizeof(buffer1), stdin);
    fflush(stdin);
    retval1 = mkfifo("/tmp/myfifo", 0666);
    fd1 = open("/tmp/myfifo", O_WRONLY);
    write(fd1, buffer1, sizeof(buffer1));
    close(fd1);

    //P2 then reads the received message by P1
    int fd, retval;
    char buffer[10];
    
    fd = open("/tmp/myfifo", O_RDONLY);
    retval = read(fd, buffer, sizeof(buffer));
    fflush(stdin);
    write(1, buffer, sizeof(buffer));
    printf("\n");
    close(fd);

    return 0;
}
