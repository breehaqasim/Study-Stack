#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#define MAXSIZE 27

void die(char *str) 
{
    perror(str);
    exit(1);
}

int main(void) 
{
    int shmid;
    key_t key = 1234;
    int *shm, *s;
    srand(time(NULL));

    if ((shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666)) < 0)
        die("shmget");
    if ((shm = shmat(shmid, NULL, 0)) == (int *)-1)
        die("shmat");

    s = shm;
    
    while (*shm != -1) 
    {
        sleep(5); //assigns every 5 seconds
        *shm = rand() % 101; //generatign random integer b/w 0-100
        printf("Writer 1: Written integer %d to shared memory.\n", *shm);
        //sleep(5); //every 5 seconds
    }

    exit(0);
}
