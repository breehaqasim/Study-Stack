#include <stdio.h>
#include <stdlib.h>
#include "my_q.h"

// enqueue’d at tail
void enqueue(struct node **headaddr, int val) 
{
    if (headaddr == NULL) 
    {
        fprintf(stderr, "NULL ptr passed\n");
        exit(1);
    }

    struct node *n = malloc(sizeof(struct node));
    
    if (n == NULL) 
    {
        fprintf(stderr, "memory allocation failed\n");
        exit(1);
    }
    
    n->val = val;
    n->next = NULL;

    if (*headaddr == NULL) 
    { // empty list
        *headaddr = n;
    } 
    else 
    {
        // get to tail
        struct node *tmp = *headaddr;
        while (tmp->next != NULL)
            tmp = tmp->next;

        tmp->next = n;
    }
}

// dequeue’d from head
int dequeue(struct node **headaddr) 
{
    if (headaddr == NULL) 
    {
        fprintf(stderr, "NULL ptr passed\n");
        exit(1);
    }

    if (*headaddr == NULL) 
    { // list is empty
        return -1;
    } 
    else 
    {
        struct node *n = *headaddr;
        *headaddr = (*headaddr)->next;
        int val = n->val;
        free(n);
        return val;
    }
}

void print(struct node *head) 
{
    if (head == NULL) 
    {
        fprintf(stdout, "empty queue\n");
    } 
    else 
    {
        while (head != NULL) 
        {
            fprintf(stdout, "%d", head->val);
            head = head->next;
        }
        fprintf(stdout, "\n");
    }
} 


void insert(struct node **headaddr, int index, int val)
{
    if (headaddr == NULL)
    {
        fprintf(stderr, "NULL ptr passed\n");
        exit(1);
    }

    struct node *newNode = malloc(sizeof(struct node));

    if (newNode == NULL)
    {
        fprintf(stderr, "memory allocation failed\n");
        exit(1);
    }

    newNode->val = val;

    //inserting at the head (index 0)
    if (index == 0)
    {
        newNode->next = *headaddr;
        *headaddr = newNode;
        return;
    }

    struct node *current = *headaddr;

    for (int i = 0; i < index - 1; i++)
    {
        if (current == NULL)
        {
            fprintf(stderr, "Index out of bounds\n");
            free(newNode);
            return;
        }
        current = current->next;
    }

    if (current != NULL)
    {
        newNode->next = current->next;
        current->next = newNode;
    }
    else
    {
        fprintf(stderr, "Index out of bounds\n");
        free(newNode);
    }
}


int removeAt(struct node **headaddr, int index)
{
    if (headaddr == NULL || *headaddr == NULL)
    {
        fprintf(stderr, "List is empty or NULL ptr passed\n");
        return -1;
    }

    struct node *current = *headaddr;

    //removing head (index 0)
    if (index == 0)
    {
        *headaddr = current->next;
        int val = current->val;
        free(current);
        return val;
    }

    for (int i = 0; i < index - 1; i++)
    {
        if (current->next == NULL)
        {
            fprintf(stderr, "Index out of bounds\n");
            return -1;
        }
        current = current->next;
    }

    struct node *toRemove = current->next;
    if (toRemove == NULL)
    {
        fprintf(stderr, "Index out of bounds\n");
        return -1;
    }

    current->next = toRemove->next;
    int val = toRemove->val;
    free(toRemove);
    return val;
}

int main() {
    struct node *head = NULL; 
    
    enqueue(&head, 2);
    enqueue(&head, 4);
    enqueue(&head, 6);
    printf("-After enqueueing-\n");
    print(head);

    insert(&head, 0, 5);
    printf("-After inserting 5 at index 0-\n");
    print(head);

    insert(&head, 2, 15);
    printf("-After inserting 15 at index 2-\n");
    print(head);

    int removedVal = removeAt(&head, 0);
    printf("-Removed value at index 0- %d\n", removedVal);
    print(head);

    removedVal = removeAt(&head, 1);
    printf("-Removed value at index 1- %d\n", removedVal);
    print(head);

    while (head != NULL) 
    {
        dequeue(&head);
    }

    return 0;
}



