#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

int main() 
{
    size_t size = 1024 * sizeof(int); //allocates memory for 1024 integer
    void *addr = (void *)0x60000000;  
    
    //maps it to a virtual address
    int *array = mmap(addr, size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

    if (array == MAP_FAILED) 
    {
        perror("mmap failed");
        exit(EXIT_FAILURE);
    }

    //writing to the allocated memory
    for (int i = 0; i < 1024; i++) 
    {
        array[i] = i * 2;  //assigning some values
    }

    //reading back to verify
    for (int i = 0; i < 1024; i++) 
    {
        printf("array[%d] = %d\n", i, array[i]);
    }

    //unampping the memory
    if (munmap(array, size) == -1) 
    {
        perror("munmap failed");
        exit(EXIT_FAILURE);
    }

    return 0;
}
