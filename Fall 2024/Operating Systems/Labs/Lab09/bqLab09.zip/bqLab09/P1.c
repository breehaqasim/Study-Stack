#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

int main(void) 
{

    //P1 reads the message first
    int fd, retval;
    char buffer[9];
    
    fd = open("/tmp/myfifo", O_RDONLY);
    retval = read(fd, buffer, sizeof(buffer));
    fflush(stdin);
    write(1, buffer, sizeof(buffer));
    printf("\n");
    close(fd);

    //P1 writes it's message to P2
    int fd1, retval1;
    char buffer1[10];
    
    printf("P1 says: ");
    fgets(buffer1, sizeof(buffer1), stdin);
    fflush(stdin);
    retval1 = mkfifo("/tmp/myfifo", 0666);
    fd1 = open("/tmp/myfifo", O_WRONLY);
    write(fd1, buffer1, sizeof(buffer1));
    close(fd1);

    return 0;
}
