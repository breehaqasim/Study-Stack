#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>


int main(int argc, char *argv[])
{
    int child_pids[4];
    printf("hello I am parent (parent pid:%d)\n", (int) getpid());

    for (int i = 0; i < 4; i++)
    {
        int rc = fork();

        if (rc < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc == 0)
        {
            printf("hello, I am child %d (pid:%d)\n", i, (int) getpid());
            exit(0);  // Child exits after printing its message
        }
        else
        {
            child_pids[i] = rc;
        }
    }

    // Using waitid to wait for all child processes
    siginfo_t info;
    for (int i = 0; i < 4; i++) 
    {
        waitid(P_ALL, 0, &info, WEXITED);

        printf("Child (PID: %d) exited", info.si_pid);
    }

    printf("Parent exiting after all children have exited.\n");
    return 0;
}
