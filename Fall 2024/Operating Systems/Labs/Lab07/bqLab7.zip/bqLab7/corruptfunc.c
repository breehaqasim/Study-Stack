#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

void corrupt_return_addr() 
{
    int arr[2];  
    printf("Address of arr[0]: %p\n", &arr[0]);
    printf("Address of arr[1]: %p\n", &arr[1]);

    uintptr_t *return_addr = (uintptr_t *)(arr + 3);  
    *return_addr = (uintptr_t)corrupt_return_addr; 

    printf("Overwriting the return address which will corrupt return address :) \n");
}

int main() 
{
    corrupt_return_addr();
    printf("NO RETURN\n");
    return 0;
}

