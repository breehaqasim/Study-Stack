#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int child_pids[4];
    printf("hello I am the parent (parent pid:%d)\n", (int) getpid());

    for (int i = 0; i < 4; i++)
    {
        int rc = fork();

        if (rc < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc == 0)
        {
            printf("hello, I am child %d (pid:%d)\n", i, (int) getpid());
            exit(0);
        }
        else
        {
            child_pids[i] = rc;
        }
    }

    for (int i = 0; i < 4; i++) {
        int status;
        int wc = waitpid(child_pids[i], &status, 0);  // Wait for the specific child to finish
        if (wc == -1) {
            perror("waitpid failed");
        } else {
            printf("Parent process waited for child with PID %d (wc:%d)\n", child_pids[i], wc);
        }
    }

    printf("Parent process (pid:%d) exits after all children\n", (int) getpid());
    return 0;
}
