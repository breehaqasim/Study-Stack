#include <stdio.h>

void guess_value_of_sec()
{
    int x = 1;
    int y = 2;
    int *ptr = &x;  //ptr to x
    int *guess_ptr_y = ptr + 1;  //Guessing that y is near by x 

    printf("Address of x (first variable) : %p\n", &x);
    printf("Address of y (guessed second variable) : %p\n", guess_ptr_y);
    printf("Value of y before change : %d\n", *guess_ptr_y);

    //verifying the guess by changing and displaying the changed value of the second variable using that changed address
    *guess_ptr = 40;

    printf("Verifying the value of y after change: %d\n", y);
    //since the value is being changed of y it means the address we guessed was corect
}

int main()
{
    guess_value_of_sec();
    return 0;
}
