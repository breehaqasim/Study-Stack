#ifndef SUB_H
#define SUB_H

int sub(int a, int b);

#endif

