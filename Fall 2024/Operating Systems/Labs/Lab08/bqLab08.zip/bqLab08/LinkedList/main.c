#include <stdio.h>
#include "linked_list.h"

int main()
{
    struct node *head = NULL;
    enqueue(&head, 2);
    enqueue(&head, 4);
    enqueue(&head, 6);
    printf("-After enqueueing-\n");
    print(head);

    insert(&head, 0, 5);
    printf("-After inserting 5 at index 0-\n");
    print(head);

    insert(&head, 2, 15);
    printf("-After inserting 15 at index 2-\n");
    print(head);

    int removedVal = removeAt(&head, 0);
    printf("-Removed value at index 0- %d\n", removedVal);
    print(head);

    removedVal = removeAt(&head, 1);
    printf("-Removed value at index 1- %d\n", removedVal);
    print(head);

    while (head != NULL)
    {
        dequeue(&head);
    }

    return 0;
}
