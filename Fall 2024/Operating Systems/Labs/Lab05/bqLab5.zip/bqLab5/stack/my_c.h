#ifndef MY_C_H
#define MY_C_H

struct node 
{
    int val;
    struct node *next;
};

void push(struct node ** headaddr, int val);
int pop(struct node ** headaddr);
void print (struct node * head);
#endif
