#include <stdio.h>
#include "add.h"
#include "sub.h"

int main()
{
    printf("Sum of 2 and 4 is %d\n", add(2, 4));
    printf("Difference b/w 3 and 5 is %d\n", sub(3, 5));
    return 0;
}
