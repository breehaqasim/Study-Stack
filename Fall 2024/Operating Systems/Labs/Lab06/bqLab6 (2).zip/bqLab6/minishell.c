#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main()
{
    char command[256];

    while (1)
    {
        printf("prompt> ");
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = '\0';  // remove newline

        if (strcmp(command, "exit") == 0)
        {
            break;
        }

        int rc = fork();
        if (rc < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc == 0)
        {
            char *args[] = {command, NULL};
            execvp(args[0], args);  // execute the command
            printf("Unknown command\n");
        }
        else
        {
            wait(NULL);  // parent waits for child to finish
        }
    }

    return 0;
}
