#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#define MAXSIZE 27

void die(char *str) 
{
    perror(str);
    exit(1);
}

int main(void) 
{
    int shmid;
    key_t key = 5678;
    double *shm, *s;
    srand(time(NULL));

    if ((shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666)) < 0)
        die("shmget");
    if ((shm = shmat(shmid, NULL, 0)) == (double *)-1)
        die("shmat");

    s = shm;
    
    while (*shm != -1) 
    {
        sleep(2); //assigns every 2 seconds
        *shm = 999.00 + (rand() / (double)RAND_MAX) * (10000.00 - 999.00);
        printf("Writer 2: Written double %.2f to shared memory.\n", *shm);
    }

    exit(0);
}
