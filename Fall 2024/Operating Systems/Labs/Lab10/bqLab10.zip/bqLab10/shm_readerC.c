#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAXSIZE 27

void die(char *str) 
{
    perror(str);
    exit(1);
}

int main(void) 
{
    int shmid_A, shmid_B;
    key_t key_A, key_B;
    int *shm_A, *shm_B;
    int n, fib;

    key_A = 2211; //key for shared memory A
    key_B = 3311; //key for shared memory B

    fflush(stdin);

    if ((shmid_A = shmget(key_A, MAXSIZE, 0666)) < 0)
        die("shmget A");
    if ((shm_A = shmat(shmid_A, NULL, 0)) == (int *)-1)
        die("shmat A");

    if ((shmid_B = shmget(key_B, MAXSIZE, 0666)) < 0)
        die("shmget B");
    if ((shm_B = shmat(shmid_B, NULL, 0)) == (int *)-1)
        die("shmat B");

    printf("Enter the number of Fibonacci numbers b/w 1-100 to generate: ");
    scanf("%d", &n);

    //the below iteration is done n times
    for (int i = 0; i < n; i++) 
    {
        int a = *shm_A; //read memory of A
        int b = *shm_B; //read memory of B

        printf("%d ", a);

        fib = a + b; //add A+B

        *shm_A = b; //assign memory of B to memory of A
        *shm_B = fib; //assign value of A+B to memory of B

        sleep(1);
    }

    printf("\n");

    exit(0);
}
