
// Function decalarations here

int add(int x, int y);