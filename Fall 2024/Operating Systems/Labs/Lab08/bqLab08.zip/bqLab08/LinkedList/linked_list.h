#ifndef LINKED_LIST_H
#define LINKED_LIST_H


struct node
{
    int val;
    struct node *next;
};


void enqueue(struct node **headaddr, int val);
int dequeue(struct node **headaddr);
void print(struct node *head);
void insert(struct node **headaddr, int index, int val);
int removeAt(struct node **headaddr, int index);

#endif
