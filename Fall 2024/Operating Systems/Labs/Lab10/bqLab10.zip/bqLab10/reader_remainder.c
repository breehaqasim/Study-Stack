#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define MAXSIZE_INT sizeof(int)
#define MAXSIZE_DOUBLE sizeof(double)

void die(char *str) 
{
    perror(str);
    exit(1);
}

int main(void) 
{
    int shmid_int, shmid_double;
    key_t key_int = 1234, key_double = 5678;
    int *shm_int;
    double *shm_double;

    if ((shmid_int = shmget(key_int, MAXSIZE_INT, 0666)) < 0)
        die("shmget int");
    if ((shm_int = shmat(shmid_int, NULL, 0)) == (int *)-1)
        die("shmat int");

    if ((shmid_double = shmget(key_double, MAXSIZE_DOUBLE, 0666)) < 0)
        die("shmget double");
    if ((shm_double = shmat(shmid_double, NULL, 0)) == (double *)-1)
        die("shmat double");

    while (1) 
    {
        int int_value = *shm_int; //reads first memory
        double double_value = *shm_double; //reads second memory

        if (int_value != 0) 
        {
            double remainder = fmod(double_value, int_value);
            printf("Reader: Remainder of %.2f %% %d = %.2f\n", double_value, int_value, remainder);
        } 
        else 
        {
            printf("Reader: Integer value is zero; cannot perform division.\n");
        }

        sleep(10);
    }

    exit(0);
}
