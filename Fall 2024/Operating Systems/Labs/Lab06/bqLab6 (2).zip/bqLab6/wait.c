#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>


int main(int argc, char *argv[])
{
    int child_pids[4];
    printf("hello I am parent (parent pid:%d)\n", (int) getpid());

    for (int i = 0; i < 4; i++)
    {
        int rc = fork();

        if (rc < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc == 0)
        {
            printf("hello, I am child %d (pid:%d)\n", i, (int) getpid());
            exit(0);  
        }
        else
        {
            child_pids[i] = rc;
        }
    }

    //parent waits for all children to finish
    for (int i = 0; i < 4; i++)
    {
        int wc = wait(NULL);
        printf("Parent process waits for child with PID %d (wc:%d) to exit\n",child_pids[i],wc);
 
    }

    printf("Parent process (pid:%d) exits after all children\n", (int) getpid());
    return 0;
}
