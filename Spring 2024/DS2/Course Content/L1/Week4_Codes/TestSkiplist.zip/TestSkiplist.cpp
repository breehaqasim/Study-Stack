// TestSkiplist.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#if 0
#include <iostream>
#include "SkiplistSSet.h"

int main()
{
    ods::SkiplistSSet<int> set;

    for (int i = 1; i <= 10; ++i)
        set.add(i);

    int items[] = {5, 7, 11, 12, 2, 4, 6};

    for (int i : items)
    { 
        int value = set.find(i);
        if (value != NULL)
            std::cout << i << " Found"  << std::endl;
        else
            std::cout << i << " Not Found" << std::endl;
    }
    return 0;
}

#endif

#if 0
#include <iostream>
#include "SkiplistList.h"

int main()
{
    ods::SkiplistList<int> list;

    for (int i = 0; i < 10; ++i)
        list.add(0, (i+1) );

    int items[] = { 5, 7, 11, 12, 2, 4, 6 };

    for (int i = 0; i < 10; ++i)
    {
        int value = list.remove(0);
        std::cout << value << std::endl;
    }
    return 0;
}
#endif
