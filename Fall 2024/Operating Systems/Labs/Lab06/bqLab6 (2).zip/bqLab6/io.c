#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/wait.h>

int main()
{
    char command[256];

    while (1)
    {
        printf("prompt> ");
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = '\0'; // remove newline

        if (strcmp(command, "exit") == 0)
        {
            break;
        }

        char *outfile = strstr(command, ">");
        if (outfile != NULL)
        {
            *outfile = '\0';
            outfile += 1;
            while (*outfile == ' ') outfile++;
        }


        int rc = fork();
        if (rc < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc == 0)
        {
            if (outfile != NULL)
            {
                int fd = open(outfile, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU);
                if (fd < 0)
                {
                    fprintf(stderr, "error opening file: %s\n", outfile);
                    exit(1);
                }
                dup2(fd, STDOUT_FILENO);
                close(fd);
            }

            char *args[10];
            char *token = strtok(command, " ");
            int i = 0;
            while (token != NULL && i < 10)
            {
                args[i++] = token;
                token = strtok(NULL, " ");
            }
            args[i] = NULL;
            execvp(args[0], args); // runs word count
            exit(1);
        }
        else
        {
            wait(NULL);
        }
    }

    return 0;
}
